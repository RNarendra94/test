
USE [TST]
GO

create trigger [Prevent_create_index2] on database

for create_index

as 

if exists (select * from master.dbo.excluded1)

begin 

raiserror('cant create',16,1) ;

rollback;

return

end

GO



