--Create this logging table in msdb
USE msdb;

CREATE TABLE SPWho2_Active
    (
      SPID INT,
      Status VARCHAR(1000) NULL,
      Login SYSNAME NULL,
      HostName SYSNAME NULL,
      BlkBy SYSNAME NULL,
      DBName SYSNAME NULL,
      Command VARCHAR(1000) NULL,
      CPUTime INT NULL,
      DiskIO BIGINT NULL, -- int
      LastBatch VARCHAR(1000) NULL,
      ProgramName VARCHAR(1000) NULL,
      SPID2 INT
      , RequestId INT NULL ,
		ReportDate datetime

    )
	ALTER TABLE SPWho2_Active ADD CONSTRAINT DF_SPWho2_Active DEFAULT GETDATE() FOR ReportDate



--Include this script in a job and schedule it as per your need. Ideally it can be done for every minute
insert into SPWho2_Active (SPID, Status,Login,hostname,BlkBy,DBName,Command,CPUTime,DiskIO,LAstBatch,ProgramName,SPID2,RequestID)
exec sp_who2 Active
GO

--Run this script to cleanup the logging table. Pass the value to @retentiondays for the number of days data you want to be retained.

Declare @retentiondays int 
SET @retentiondays = 2
Delete from SPWho2_Active 
Where ReportDate < DATEADD(dd,-@retentiondays,getdate())

