

-------------DATABASE SNAPSHOT


sp_helpdb test


create database lokeshss_123 ON 
(NAME = lokeshss_123, FILENAME =
'C:\Program Files\Microsoft SQL Server\MSSQL13.MSSQLSERVER\MSSQL\DATA\lokeshss_snapshot.mdf')
AS SNAPSHOT OF [TEST]


RESTORE DATABASE lokeshss_1234 FROM
DATABASE_SNAPSHOT = 'test'
