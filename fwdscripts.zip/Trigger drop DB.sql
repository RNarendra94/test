



USE Master
GO
CREATE TRIGGER Drop_Database1 ON ALL SERVER
FOR DROP_DATABASE
AS
RAISERROR('cant drop', 16,1);
ROLLBACK;
GO



